// JavaScript
document.getElementById('welcome').innerText +=
" Editors";

var  perfectionist= 0; //1
var  selfcontrol= 0; //1
var peoplePleaser = 0;//2
var generous = 0;//2
var  driven= 0;//3
var adaptive = 0;//3
var  dramatic= 0;//4
var selfAbsorbed=0;//4
var isolated =0;//5
var innovative =0;//5
var responsible=0;//6
var engaging = 0;//6
var  scattererd=0;//7
var spontaneous=0;//7

var willful =0;//8
var confrontational = 0;//8
var agreeable =0;//9
var  complacent =0;//9

if(document.getElementById('nothing1').checked) {
  perfectionist = perfectionist -1 ;
}else if(document.getElementById('half1').checked) {
  perfectionist = perfectionist ;
}else if(document.getElementById('whole1').checked) {
  perfectionist = perfectionist + 1 ;
}








var typeOne =perfectionist + selfcontrol;
var typeTwo = peoplePleaser + generous;
var typeThree=driven + adaptive;
var typeFour= dramatic + selfAbsorbed;
var typeFive= isolated + innovative;
var typeSix = responsible + engaging;
var typeSeven= scattererd +spontaneous;
var typeEight =willful + confrontational;
var typeNine= complacent + agreeable;
